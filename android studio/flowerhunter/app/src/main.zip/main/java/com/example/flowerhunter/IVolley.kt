package com.example.flowerhunter

interface IVolley {
    fun onResponse(response: String)
}