package com.example.flowerhunter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.JsonReader
import android.widget.Toast
import androidx.core.view.isVisible
import kotlinx.android.synthetic.main.activity_picture.*
import org.json.JSONObject
import org.xml.sax.Parser

class PictureActivity : AppCompatActivity(),IVolley {

    override fun onResponse(response: String) {
        Toast.makeText(this,"222", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_picture)
        val bundle = intent.extras
       // val theme: String? = bundle!!.getString("theme")
      //  val t = JSONObject(theme.toString())
        val title = bundle!!.getString("title")
        val content = bundle.getString("content")
        val ch = title!!.split(",")
        //val stringBuilder: StringBuilder = StringBuilder(theme.toString())

        //val json: JSONObject = parser.parse(stringBuilder) as JSONObject
      //  button.setOnClickListener {
            image_view.setImageUrl("https://phase3-257520.appspot.com/"+ch[1],
                MyVolleyRequest.getInstance(this).imageLoader)
            //button.isVisible=false
            textView2.setText(ch[0])
            textView3.setText(content)
    //    }
    }


}
