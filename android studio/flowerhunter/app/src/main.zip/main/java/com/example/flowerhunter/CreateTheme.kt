@file:Suppress("DEPRECATION")
package com.example.flowerhunter

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Environment
import java.io.File
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.camera.imageView
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_create_theme.*
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.net.*
import java.nio.Buffer


class CreateTheme : AppCompatActivity() {


    private var themeName: EditText? = null
    private var themeDescription: EditText? = null
    private var saveButton: Button? = null

    var picFileName = "test.png"
    var dir = Environment.getExternalStorageDirectory()
    var saveLocation = File(dir, picFileName)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_theme)

        //Linking variables to user input boxes
        themeName = findViewById(R.id.themename) as EditText
        themeDescription = findViewById(R.id.themedescription) as EditText

        //Displaying test.png in local directory that the user took with the camera on this page

        Picasso
            .get()
            .load(saveLocation)
            .into(imageView)



        btnTakePicture.setOnClickListener {
            val intent = Intent(this, Camera::class.java)
            startActivity(intent)
        }

        btnOk.setOnClickListener {
            //Save user input to variables
            val nameToSend = themeName!!.text.toString()
            val descToSend = themeDescription!!.text.toString()

            //I copied this from Ashkan as a starting point for the POST
            var response = ""

            object : Thread(){
                override fun run() {

                    val size = saveLocation.length() as Int
                    val bytes = ByteArray(size)
                    val buf = BufferedInputStream(FileInputStream(saveLocation))
                    buf.read(bytes,0,bytes.size)
                    buf.close()





                    response = URL("https://phase3-257520.appspot.com/create_theme"
                            + "_" + MainActivity.username
                            + "_" + nameToSend
                            + "_" + descToSend
                            + "_" + bytes).readText()
                }
            }.start()

            //val picToSend = saveLocation.toString()
            val intent = Intent(this, Home::class.java)
            startActivity(intent)

            Toast.makeText(this, "Data saved", Toast.LENGTH_SHORT).show()
        }

        btnCancel.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)        
        }
    }

}

//I started to set up a bitmap to Base64 converter but did not know if the POST was working
//so I could not test it.

/*fun Bitmap.encodeBitmapIntoBase64(compressFormat: Bitmap.CompressFormat, quality: Int = 0): String {
    val baseArrayOutputStream = ByteArrayOutputStream()
    compress(compressFormat, quality, baseArrayOutputStream)
    val imageBytes = baseArrayOutputStream.toByteArray()
    return Base64.encodeToString(imageBytes, Base64.DEFAULT)
}*/
